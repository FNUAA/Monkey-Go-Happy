
var monkey, monkey_running;

var banana , bananaImage;

var obstacle, obstacleImage;

var score;

var ground;

function preload(){
  monkey_running = loadAnimation("sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png" );
  obstacle = loadImage("obstacle.png");
  
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png");
  
  bananaImage = loadImage("banana.png");
  banana.addImage(bananaImage);
  
  obstaceImage = loadImage("obstacle.png"); 
}



function setup() {
  createCanvas(600, 200);
  
  monkey = createSprite(50, 160, 20, 50);
  monkey.addAnimation("running", monkey_running)
  monkey.scale = 0.5;
  
  ground = createSprite(300,-100, 1200, 10)
  
  text("Score: " + score, 500, 50) 
  if(frameCount % 60 === 0) {
    score = score + 1;
  }
  
  
  if(frameCount % 6000 === 0) {
    var banana = createSprite(300,300,10,10)
  }
  
  if(frameCount % 300 === 0) {
    var obstacle = createSprite(300,300,30,30)
  }
  
  monkey.velocityY = -12
  if(monkey.isTouching("ground")) {
    monkey.velocityY = monkey.velocityY + 12;
  }
  if(keyDown("SPACE")) {
    monkey.velocityY = 6;
  }
  

  
}


function draw() {
  ground.velocityX = -3;
  if(ground.x < 0) {
    ground.width = ground.width + 600;
  }

  
}






